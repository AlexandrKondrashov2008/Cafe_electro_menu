import sys
import urllib.request
from io import BytesIO
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QPushButton, QTextEdit,
                             QTabWidget, QScrollArea, QGridLayout, QFrame,
                             QMessageBox, QSpinBox, QGroupBox, QListWidget,
                             QListWidgetItem, QDialog, QDialogButtonBox)
from PyQt5.QtCore import Qt, QSize, QThread, pyqtSignal
from PyQt5.QtGui import QFont, QPixmap, QPalette, QBrush, QLinearGradient, QColor, QIcon


class ImageLoader(QThread):
    """Загрузка изображений в отдельном потоке"""
    image_loaded = pyqtSignal(str, QPixmap)

    def __init__(self, url, dish_name):
        super().__init__()
        self.url = url
        self.dish_name = dish_name

    def run(self):
        try:
            headers = {'User-Agent': 'Mozilla/5.0'}
            req = urllib.request.Request(self.url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as response:
                image_data = response.read()
                pixmap = QPixmap()
                pixmap.loadFromData(image_data)
                if not pixmap.isNull():
                    self.image_loaded.emit(self.dish_name, pixmap)
        except Exception as e:
            print(f"Ошибка загрузки {self.dish_name}: {e}")


class MenuItem:
    """Класс для хранения информации о блюде"""

    def __init__(self, name, category, price, ingredients, image_url=None):
        self.name = name
        self.category = category
        self.price = price
        self.ingredients = ingredients
        self.image_url = image_url
        self.image_pixmap = None


class OrderItem(QWidget):
    """Виджет для отображения позиции в заказе с картинкой"""

    def __init__(self, menu_item, quantity, parent=None):
        super().__init__(parent)
        self.menu_item = menu_item
        self.quantity = quantity
        self.setup_ui()

    def setup_ui(self):
        layout = QHBoxLayout()
        layout.setSpacing(10)
        layout.setContentsMargins(10, 5, 10, 5)

        self.image_label = QLabel()
        self.image_label.setFixedSize(60, 60)
        self.image_label.setStyleSheet("border-radius: 8px; background-color: #f0f0f0;")
        self.image_label.setAlignment(Qt.AlignCenter)

        if self.menu_item.image_pixmap and not self.menu_item.image_pixmap.isNull():
            pixmap = self.menu_item.image_pixmap.scaled(60, 60, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.image_label.setPixmap(pixmap)
        else:
            self.image_label.setText("🍽️")
            self.image_label.setFont(QFont("Segoe UI Emoji", 20))

        layout.addWidget(self.image_label)

        info_layout = QVBoxLayout()

        name_label = QLabel(self.menu_item.name)
        name_label.setFont(QFont("Segoe UI", 12, QFont.Bold))
        name_label.setStyleSheet("color: #2c3e50;")
        info_layout.addWidget(name_label)

        price_label = QLabel(f"{self.menu_item.price} ₽ × {self.quantity} = {self.menu_item.price * self.quantity} ₽")
        price_label.setFont(QFont("Segoe UI", 10))
        price_label.setStyleSheet("color: #e74c3c;")
        info_layout.addWidget(price_label)

        layout.addLayout(info_layout, 1)

        self.setLayout(layout)
        self.setStyleSheet("""
            OrderItem {
                background-color: white;
                border-radius: 10px;
                margin: 2px;
            }
            OrderItem:hover {
                background-color: #f8f9fa;
            }
        """)


class ModernButton(QPushButton):
    """Современная стилизованная кнопка"""

    def __init__(self, text, default_color="#4CAF50", enabled=True):
        super().__init__(text)
        self.default_color = default_color
        self.active_color = "#4CAF50"
        self.current_color = default_color
        self.is_active = False
        self.setCursor(Qt.PointingHandCursor if enabled else Qt.ArrowCursor)
        self.setEnabled(enabled)
        self.update_style()

    def set_active(self, active):
        self.is_active = active
        if active:
            self.current_color = self.active_color
        else:
            self.current_color = self.default_color
        self.update_style()

    def update_style(self):
        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {self.current_color};
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 10px;
                font-size: 14px;
                font-weight: bold;
            }}
            QPushButton:hover:enabled {{
                background-color: {self.adjust_color(-20)};
            }}
            QPushButton:pressed:enabled {{
                background-color: {self.adjust_color(-40)};
            }}
            QPushButton:disabled {{
                background-color: #cccccc;
                color: #999999;
            }}
        """)

    def adjust_color(self, amount):
        color = self.current_color.lstrip('#')
        r, g, b = tuple(int(color[i:i + 2], 16) for i in (0, 2, 4))
        r = max(0, min(255, r + amount))
        g = max(0, min(255, g + amount))
        b = max(0, min(255, b + amount))
        return f"#{r:02x}{g:02x}{b:02x}"


class DishCard(QFrame):
    """Карточка блюда с картинкой"""
    dish_clicked = pyqtSignal(object)

    def __init__(self, menu_item, parent=None):
        super().__init__(parent)
        self.menu_item = menu_item
        self.setup_ui()

    def setup_ui(self):
        self.setFrameStyle(QFrame.NoFrame)
        self.setMinimumSize(220, 280)
        self.setMaximumSize(220, 280)
        self.setCursor(Qt.PointingHandCursor)

        self.setStyleSheet("""
            DishCard {
                background-color: white;
                border-radius: 15px;
            }
            DishCard:hover {
                background-color: #f8f9fa;
            }
        """)

        layout = QVBoxLayout()
        layout.setSpacing(8)
        layout.setContentsMargins(10, 10, 10, 10)

        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setMinimumHeight(140)
        self.image_label.setMaximumHeight(140)
        self.image_label.setStyleSheet("border-radius: 10px; background-color: #f0f0f0;")

        if self.menu_item.image_pixmap and not self.menu_item.image_pixmap.isNull():
            pixmap = self.menu_item.image_pixmap.scaled(200, 130, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.image_label.setPixmap(pixmap)
        else:
            self.image_label.setText("🍽️")
            self.image_label.setFont(QFont("Segoe UI Emoji", 48))

        layout.addWidget(self.image_label)

        name_label = QLabel(self.menu_item.name)
        name_label.setFont(QFont("Segoe UI", 12, QFont.Bold))
        name_label.setAlignment(Qt.AlignCenter)
        name_label.setWordWrap(True)
        name_label.setStyleSheet("color: #2c3e50;")
        layout.addWidget(name_label)

        category_label = QLabel(self.menu_item.category)
        category_label.setFont(QFont("Segoe UI", 9))
        category_label.setAlignment(Qt.AlignCenter)
        category_label.setStyleSheet("color: #7f8c8d;")
        layout.addWidget(category_label)

        price_label = QLabel(f"{self.menu_item.price} ₽")
        price_label.setFont(QFont("Segoe UI", 14, QFont.Bold))
        price_label.setAlignment(Qt.AlignCenter)
        price_label.setStyleSheet("color: #e74c3c;")
        layout.addWidget(price_label)

        self.setLayout(layout)

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.dish_clicked.emit(self.menu_item)


class CafeApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Электронное меню")
        self.setGeometry(50, 50, 1400, 900)

        self.set_modern_style()

        self.order_items = []
        self.image_loaders = []
        self.selected_dish = None

        self.init_menu_data()
        self.setup_ui()
        self.load_images()

    def set_modern_style(self):
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            QTabWidget::pane {
                border: none;
                background-color: white;
                border-radius: 10px;
                margin-top: 5px;
            }
            QTabBar::tab {
                background-color: #e0e0e0;
                padding: 15px 40px;
                margin-right: 5px;
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                font-size: 15px;
                font-weight: bold;
                font-family: Segoe UI;
                min-width: 150px;
            }
            QTabBar::tab:selected {
                background-color: #4CAF50;
                color: white;
            }
            QTabBar::tab:hover:!selected {
                background-color: #bdbdbd;
            }
            QScrollBar:vertical {
                border: none;
                background-color: #f0f0f0;
                width: 10px;
                border-radius: 5px;
            }
            QScrollBar::handle:vertical {
                background-color: #4CAF50;
                border-radius: 5px;
                min-height: 20px;
            }
            QListWidget {
                border: none;
                background-color: transparent;
            }
            QListWidget::item {
                background-color: transparent;
                padding: 5px;
            }
        """)

    def init_menu_data(self):
        """Инициализация данных меню с обновленными фото"""
        self.menu_items = [
            # Закуски
            MenuItem("Брускетта с томатами", "Закуски", 250,
                     "Свежие томаты, базилик, оливковое масло, чеснок, багет",
                     "https://lifehacker.ru/wp-content/uploads/2020/01/shutterstock_454361815_1579876041-e1579876086639-scaled.jpg"),
            MenuItem("Сырная тарелка", "Закуски", 450,
                     "Пармезан, дорблю, камамбер, мед, орехи",
                     "https://home-restaurant.ru/wp-content/uploads/2011/01/syrnaya_tarelka_foto_9.jpg"),
            MenuItem("Карпаччо из говядины", "Закуски", 380,
                     "Говядина, пармезан, руккола, лимон, оливковое масло",
                     "https://vkusvill.ru/upload/resize/806046/karpachcho-iz-govyadiny_588x409x90_c.webp"),
            MenuItem("Оливки ассорти", "Закуски", 180,
                     "Зеленые и черные оливки с лимоном",
                     "https://www.jacks.ru/f/product/Olivkovaya-tarelka.jpg"),
            MenuItem("Креветки в кляре", "Закуски", 420,
                     "Креветки, кляр, соус сладкий чили",
                     "https://lafoy.ru/photo_l/foto-1777-0.jpg"),
            MenuItem("Спринг-роллы", "Закуски", 280,
                     "Овощи, рисовая бумага, соус терияки",
                     "https://www.kikkoman.ru/fileadmin/_processed_/e/b/csm_143-recipe-page-Fresh-Spring-Rolls-with-Teriyaki-Aubergine_desktop_8f13a454b2.jpg"),
            MenuItem("Тако с курицей", "Закуски", 320,
                     "Курица, салат, соус сальса, тортилья",
                     "https://www.koolinar.ru/all_image/recipes/124/124526/recipe_1e536f05-2949-401f-be53-24390a7565bd.jpg"),
            MenuItem("Жюльен с грибами", "Закуски", 350,
                     "Шампиньоны, сливки, сыр, лук",
                     "https://prostokvashino.ru/upload/resize_cache/iblock/232/800_800_0/232526f4d010cfd75c33784ee55f0175.jpg"),
            MenuItem("Крылышки BBQ", "Закуски", 390,
                     "Куриные крылья, соус барбекю",
                     "https://s1.eda.ru/StaticContent/Photos/120213181523/180606193911/p_O.jpg"),
            MenuItem("Луковые кольца", "Закуски", 220,
                     "Лук в кляре, соус ранч",
                     "https://www.photorecept.ru/wp-content/uploads/2021/12/hrustjashhie-lukovye-kolca.jpg"),
            MenuItem("Начос с сыром", "Закуски", 290,
                     "Кукурузные чипсы, сырный соус, халапеньо",
                     "https://www.delicados.ru/images/recipes/catalog/nachos-s-sirnim-sousom.jpg"),
            MenuItem("Мини-бургеры", "Закуски", 380,
                     "3 мини-бургера с говядиной, сыром и соусом",
                     "https://images.gastronom.ru/HHDWBwo9YmHFsMhEEfQA-h2gj0o1ATJV05bWW3GuZx8/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzLzMxMWQzYTFjLWQwYmMtNDU1ZS1iOGM3LTljOTM2NGY0ZGVlYS5qcGc.webp"),

            # Салаты
            MenuItem("Салат Цезарь", "Салаты", 320,
                     "Курица, пармезан, сухарики, соус Цезарь, салат романо",
                     "https://images.gastronom.ru/-UHzDgNx-m0MMa6OR0ilz2qP7MB0mKQeGceObc9jpck/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzLzVhNzFhZGY1LTM3MTYtNDlmMy04NDNlLTAwMTg4MGNiM2E0OS5qcGc.webp"),
            MenuItem("Греческий салат", "Салаты", 280,
                     "Фета, оливки, огурцы, помидоры, перец, красный лук",
                     "https://art-lunch.ru/content/uploads/2018/07/Greek_salad.jpg"),
            MenuItem("Салат с лососем", "Салаты", 420,
                     "Лосось, микс салата, авокадо, огурец, соус песто",
                     "https://images.gastronom.ru/T1UDFEH475Q8lfVBKrjUKYwg2d3ugTqKaifrP5SXA6o/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2FjNjU1MjMwLWM2NjEtNDZiNC1iY2JlLWFlYjg3NmY2YzM1ZC5qcGc.webp"),
            MenuItem("Салат с тунцом", "Салаты", 450,
                     "Тунец, микс салата, огурец, помидоры черри",
                     "https://hoff.ru/upload/medialibrary/b53/vtu12a1ti8yi71kqcxthv0ekh0yt6hzi.jpg"),
            MenuItem("Нисуаз", "Салаты", 480,
                     "Тунец, яйцо, фасоль, анчоусы, оливки",
                     "https://cdnn21.img.ria.ru/images/07e9/02/06/1997763386_0:217:3068:1943_1920x1080_80_0_0_0ca8ba839de72d6ed951096f9054992c.jpg"),
            MenuItem("Теплый салат с овощами", "Салаты", 350,
                     "Гриль овощи, бальзамический соус",
                     "https://s1.eda.ru/StaticContent/Photos/b/96/b9637b1cfb1040d4b47fa5c4c52d0643.jpg"),
            MenuItem("Салат Оливье", "Салаты", 290,
                     "Колбаса, горошек, яйца, картофель, морковь, майонез",
                     "https://images.gastronom.ru/sI2Z_hS9qg62A_PIvSNDCqpsBvIKqOpRSYTVehfE9KA/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2QxOTg4MmNjLTU1YjAtNDQ5ZS05Nzc3LTkzNDUzNGYxMzZkMi5qcGc.webp"),
            MenuItem("Салат Мимоза", "Салаты", 310,
                     "Сайра, яйца, сыр, картофель, лук, майонез",
                     "https://images.gastronom.ru/Spk4lxiuTjmy8VHPC_usbmGa6g_fwZEXuLQxWnJgaic/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2U2NWU1Y2EyLTllZTEtNGM4ZC05ZTdlLWMwZWY2OTVkZDRkOC5qcGc.webp"),
            MenuItem("Салат Витаминный", "Салаты", 260,
                     "Капуста, морковь, яблоко, оливковое масло",
                     "https://vkusvill.ru/upload/resize/650987/salat-vitaminnyy-iz-kapusty-i-morkovi_588x409x90_c.webp"),
            MenuItem("Салат Крабовый", "Салаты", 370,
                     "Крабовые палочки, кукуруза, яйца, рис, майонез",
                     "https://images.gastronom.ru/WDdNs6cApNrBxZrlM8GgdXlv10ImYbmMmYAiB2MC0Cw/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzLzZiMjRhNjU2LWYwYjktNDJhMS1hODg1LWQyMmVmYzdiNmM4Yy5qcGc.webp"),
            MenuItem("Салат Греческий с креветками", "Салаты", 490,
                     "Креветки, фета, оливки, огурцы, томаты",
                     "https://images.gastronom.ru/mwmzOe0evlO65YajE9jlQ_bYgK8X_lQR1ddrLc9_1wU/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2RjNGRkYjM4LWIzMmEtNGRjZC1iOWUzLWM4NGQ1YWFlMDVmMS5qcGc.webp"),
            MenuItem("Салат Фруктовый", "Салаты", 300,
                     "Яблоко, груша, апельсин, виноград, йогурт",
                     "https://images.gastronom.ru/xx8vnPTumPBABpaMkQIQrO_75nZ0fxSuDQcvJj3gGdE/pr:article-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzLzVmYWM5ZmZlLTJmZjEtNDJlOS05NDc2LTE4OWFhYjNkNmZmNy5qcGc.webp"),

            # Супы (с обновленными фото)
            MenuItem("Суп-пюре из тыквы", "Супы", 250,
                     "Тыква, сливки, семечки, имбирь",
                     "https://www.russianfood.com/dycontent/images_upl/545/big_544330.jpg"),
            MenuItem("Борщ", "Супы", 280,
                     "Свекла, капуста, картофель, мясо, сметана, зелень",
                     "https://lifehacker.ru/wp-content/uploads/2019/09/Kak_prigotovit_borshh_po_klassicheskomu_receptu_1758180874.jpeg"),
            MenuItem("Том Ям", "Супы", 350,
                     "Креветки, грибы, кокосовое молоко, лемонграсс, чили",
                     "https://vkusvill.ru/upload/resize/1046176/tom-yam_588x409x90_c.webp"),
            MenuItem("Суп с фрикадельками", "Супы", 290,
                     "Куриные фрикадельки, лапша, овощи",
                     "https://cdnn21.img.ria.ru/images/07e8/09/0d/1972561651_0:160:3072:1888_1920x0_80_0_0_927573682eb5cea7da03a81e6789779e.jpg"),
            MenuItem("Солянка мясная", "Супы", 320,
                     "Говядина, колбасы, оливки, лимон, сметана",
                     "https://images.samsung.com/is/image/samsung/assets/ru/cooking-hub/recipes/microwave-oven-solo/meat-hodgepodge/main_desktop.jpg"),
            MenuItem("Крем-суп из брокколи", "Супы", 270,
                     "Брокколи, сливки, сыр, сухарики",
                     "https://eco-buffet.com/wp-content/uploads/2024/03/sup-piure-z-brokoli.jpg"),
            MenuItem("Окрошка", "Супы", 260,
                     "Квас, овощи, яйцо, колбаса, сметана",
                     "https://images.gastronom.ru/n6mi9Uc_1AkEREZoUiJrac055P0PH2FfJL0qOq2P3EA/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2EzNjRhODgyLWMwODgtNDIwZi1hMzcwLTE4MTgxZGE3ZWNmMi5wbmc.webp"),
            MenuItem("Уха царская", "Супы", 420,
                     "Лосось, семга, картофель, сливки, зелень",
                     "https://i.ytimg.com/vi/CAi3VhHRJdA/maxresdefault.jpg"),
            MenuItem("Суп Харчо", "Супы", 310,
                     "Говядина, рис, грецкие орехи, ткемали, чеснок",
                     "https://images.gastronom.ru/gr0oDLB7RwU1RgSgXG1G0k9bXYsOVPzgH-SBpfBAKss/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2Y5MzAyZWJhLThjYjktNDE4ZC05MzY3LTYwMWI4MWYzYjdhOC5qcGc.webp"),
            MenuItem("Суп Минестроне", "Супы", 280,
                     "Овощи, томаты, паста, оливковое масло",
                     "https://images.gastronom.ru/fd2bK388T75Vn-hENthU5mNe-7vn32d3H9xReyaDLFs/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzLzcwN2ZhZTRhLWJmMmMtNDk3Mi1iODNmLWM2NDcyYjFhNTVjMi5qcGc.webp"),
            MenuItem("Грибной суп", "Супы", 290,
                     "Белые грибы, картофель, сливки, зелень",
                     "https://images.gastronom.ru/kPNOg_GOKrJF9e0M1b7isEkt3-b-Eb96kHFs9Z8R2Ro/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzLzZlM2E2NzgxLWIxYzMtNGM1OC04MmZhLWJiZTRjZDgwNDE0YS5qcGc.webp"),
            MenuItem("Сырный суп", "Супы", 320,
                     "Плавленый сыр, курица, овощи, гренки",
                     "https://www.chefmarket.ru/blog/wp-content/uploads/2021/06/cheese-soup-2000x1200.jpg"),

            # Пиццы
            MenuItem("Пицца Маргарита", "Пиццы", 450,
                     "Томатный соус, моцарелла, свежие томаты, базилик",
                     "https://lh3.googleusercontent.com/-F7-f2RyixFJ_0-MIGehlz7lp08CkWuy7Y64qDx8zcSrAyHA_uWVnJx1XOVAHg_qoFD7fW34aWScKlOz7tlHx8LeBxDoB64vaZ6LCKKMAPPnr8-QTpPpQVVK-xGPWFZomSVkVZXW"),
            MenuItem("Пицца Пепперони", "Пиццы", 520,
                     "Томатный соус, моцарелла, пепперони, орегано",
                     "https://images.gastronom.ru/hm6qPf0nZBEGFcLRG3PwM-94j23zgIZkzRlDgv7WVaY/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2RkMDc1ODA1LTliNzItNDgxOS1hMzgwLTQ0YzlhMWM5NTA0My5qcGc.webp"),
            MenuItem("Пицца Гавайская", "Пиццы", 550,
                     "Томатный соус, моцарелла, курица, ананасы",
                     "https://kulinarnia.ru/wp-content/uploads/2016/01/pitstsa-gavayskaya-s-ananasami-recept.jpg"),
            MenuItem("Пицца Четыре сыра", "Пиццы", 580,
                     "Моцарелла, пармезан, горгонзола, фета",
                     "https://goldfish-cafe.ru/luberci/wp-content/uploads/sites/10/2024/01/4sira-1.jpg"),
            MenuItem("Пицца Карбонара", "Пиццы", 560,
                     "Сливочный соус, моцарелла, бекон, яйцо, пармезан",
                     "https://tulinovculinary.ru/wp-content/uploads/2025/07/f1d52ef0-6f88-4300-b66a-9e40de672ce0-scaled.jpg"),
            MenuItem("Пицца Мясная", "Пиццы", 620,
                     "Томатный соус, моцарелла, бекон, пепперони, ветчина",
                     "https://pizzamuka.ru/wp-content/uploads/2020/12/myasnaya_5.jpg"),
            MenuItem("Пицца Вегетарианская", "Пиццы", 490,
                     "Томатный соус, моцарелла, грибы, перец, оливки, кукуруза",
                     "https://baking-academy.ru/upload/iblock/1ba/1bac340c99632765ce557aec8a1d39b3.jpg"),
            MenuItem("Пицца Диабло", "Пиццы", 590,
                     "Острый томатный соус, пепперони, халапеньо, моцарелла",
                     "https://cdn-ru16.foodpicasso.com/assets/2025/03/27/94def0706c4989e2c2212aa41518451f---jpg_1000x_103c0_convert.jpg"),
            MenuItem("Пицца Барбекю", "Пиццы", 600,
                     "Соус барбекю, курица, бекон, сыр, красный лук",
                     "https://haiku-sushi.ru/wa-data/public/shop/products/38/04/438/images/731/731.750x0@2x.jpg"),
            MenuItem("Пицца Морепродукты", "Пиццы", 680,
                     "Креветки, мидии, кальмары, соус альфредо",
                     "https://chudobludo.com/pizza-with-shrimp-shrimp-shrimp-table.jpg"),
            MenuItem("Пицца Трюфельная", "Пиццы", 750,
                     "Белый соус, моцарелла, трюфельное масло, пармезан",
                     "https://www.osteria.ru/upload/resize_cache/webp/iblock/27e/g4r9ysr1s8qly46tz0ki9x0zx1rf8nbg/IMG_0999.webp"),
            MenuItem("Пицца Песто", "Пиццы", 580,
                     "Соус песто, курица, вяленые томаты, кедровые орехи",
                     "https://img.povar.ru/mobile/a3/07/41/3a/picca_s_sousom_pesto-173389.jpg"),

            # Горячее (с обновленными фото)
            MenuItem("Стейк из говядины", "Горячее", 650,
                     "Говядина, картофель гриль, овощи гриль, соус демиглас",
                     "https://hbgrill.ru/wp-content/uploads/2021/07/steik1.png"),
            MenuItem("Паста Карбонара", "Горячее", 380,
                     "Спагетти, бекон, пармезан, яйцо, сливки",
                     "https://img.iamcook.ru/old/upl/recipes/cat/u6009-8e00fe26949a37ddf403c897f0081cf6.jpg"),
            MenuItem("Рис с овощами", "Горячее", 280,
                     "Рис, перец, морковь, горошек, кукуруза, соевый соус",
                     "https://static.1000.menu/img/content-v2/c4/09/43427/ris-s-ovoshchami-na-skovorode_1617258574_15_max.jpg"),
            MenuItem("Лосось на гриле", "Горячее", 550,
                     "Лосось, овощное соте, лимон, соус терияки",
                     "https://static.tildacdn.com/tild6362-6134-4835-b832-386538323538/1716378.jpg"),
            MenuItem("Свиные ребрышки", "Горячее", 590,
                     "Свиные ребра, соус BBQ, картофель",
                     "https://images.gastronom.ru/KafY0GQm23lnuDdW-hIp7oNih80r9-VnE4Hr5TAALo0/pr:article-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2I4NDhhN2EwLTVhZTEtNDlkNi1iMGRkLTRkZjM4OGU5YTE5MC5qcGc.webp"),
            MenuItem("Курица с овощами", "Горячее", 420,
                     "Куриное филе, цукини, перец, соус терияки",
                     "https://img.iamcook.ru/old/upl/recipes/cat/u1169-c8338c700c52d3dc7043abce47bef4fa.JPG"),
            MenuItem("Утиная грудка", "Горячее", 680,
                     "Утка, ягодный соус, запеченный картофель",
                     "https://cooklikemary.ru/sites/default/files/styles/top_slider/public/img_8769.jpg?itok=4xFv0X0i&sc=5466e59c4a933a1a9bcdb65cc9b9ed75"),
            MenuItem("Ризотто с грибами", "Горячее", 450,
                     "Рис арборио, белые грибы, пармезан, трюфельное масло",
                     "https://optim.tildacdn.one/tild3239-3330-4561-a232-396465393133/-/resize/824x/-/format/webp/__.jpg.webp"),
            MenuItem("Телятина с овощами", "Горячее", 620,
                     "Телятина, цукини, перец, соус демиглас",
                     "https://i.ytimg.com/vi/1JwZt3J7KAY/hqdefault.jpg"),
            MenuItem("Котлеты по-киевски", "Горячее", 480,
                     "Куриное филе, сливочное масло, картофельное пюре",
                     "https://www.chefmarket.ru/blog/wp-content/uploads/2019/02/chop-home-e1550169837580.jpg"),
            MenuItem("Лагман", "Горячее", 440,
                     "Домашняя лапша, говядина, овощи, бульон",
                     "https://images.gastronom.ru/RG5UgPWcyzzyZBEOFURH1100igw8tuJHVxxhBDvb5H8/pr:article-preview-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2VjMDE3MjJhLTFhNjEtNDg1NC04YTcxLTM2OGZiNDUxZTA3ZS5qcGc"),
            MenuItem("Шашлык из баранины", "Горячее", 590,
                     "Баранина, лук, соус ткемали, лаваш",
                     "https://images.gastronom.ru/0Kw9TjywO2VuE4mc3rQ6PsHuLBG71q8pyylqXOfNfn0/pr:article-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2VmMTRlMjAxLWNhNTEtNGI1MC05ZTg2LWY4YWExZjJlYzc3Mi5qcGc.webp"),

            # Десерты
            MenuItem("Тирамису", "Десерты", 280,
                     "Печенье савоярди, маскарпоне, кофе, какао",
                     "https://n1s1.hsmedia.ru/36/c4/63/36c463a07faccdc485ce66a91cfb5c3f/728x486_1_edd0996fffcf3a2bd36d266d6b88566c@5000x3335_0x8WpCwYj0_5896890447979178943.jpg.webp"),
            MenuItem("Чизкейк", "Десерты", 250,
                     "Сливочный сыр, печенье, ягоды",
                     "https://prostokvashino.ru/upload/resize_cache/iblock/668/800_800_0/668fac618d034d52e449cdeb173d7aec.jpg"),
            MenuItem("Медовик", "Десерты", 220,
                     "Медовые коржи, сметанный крем",
                     "https://onetable.ru/wp-content/uploads/2025/03/gotovyy-medovik-952x472.jpg"),
            MenuItem("Панна-котта", "Десерты", 260,
                     "Сливки, ваниль, ягодный соус",
                     "https://vkusnoff.com/img/recepty/2563/big.webp"),
            MenuItem("Шоколадный фондан", "Десерты", 320,
                     "Шоколадный кекс с жидкой начинкой, мороженое",
                     "https://lasunka.com/image1.jpg"),
            MenuItem("Эклеры", "Десерты", 240,
                     "Заварные пирожные с заварным кремом",
                     "https://lasunka.com/eklery-s-maslyanym-kremom.jpg"),
            MenuItem("Фруктовый тарт", "Десерты", 280,
                     "Песочное тесто, заварной крем, свежие фрукты",
                     "https://images.gastronom.ru/Zaml9bDjXv4E8Ph9fZOOSAIMaa23Ty3q-jCf-7CEUWM/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2JhZWMzNDg0LWU4NzgtNGYzOC05MmE4LWRkY2M5NTE4ODZkYS5qcGc.webp"),
            MenuItem("Мороженое ассорти", "Десерты", 180,
                     "Шарики ванильного, шоколадного и клубничного мороженого",
                     "https://mdolina.ru/userfls/shop/1920/1246_morozhenoe--assorti-plomb.jpg"),
            MenuItem("Брауни с мороженым", "Десерты", 340,
                     "Шоколадное брауни, ванильное мороженое, шоколадный соус",
                     "https://lasunka.com/brauni.png"),
            MenuItem("Чизкейк Нью-Йорк", "Десерты", 290,
                     "Классический чизкейк с ягодным соусом",
                     "https://pteat.ru/wp-content/uploads/2025/03/itogovoe-4.jpg"),
            MenuItem("Профитроли", "Десерты", 260,
                     "Заварные пирожные с заварным кремом",
                     "https://paulinecakeclub.ru/wp-content/uploads/2023/08/profitroli-s-kremom-plombir-foto-1-1024x683.jpg"),
            MenuItem("Морковный торт", "Десерты", 270,
                     "Влажный морковный торт со сливочным сыром",
                     "https://e0.edimdoma.ru/data/recipes/0005/9198/59198-ed4_wide.jpg?1759144306"),

            # Напитки
            MenuItem("Капучино", "Напитки", 180,
                     "Эспрессо, вспененное молоко",
                     "https://www.nescafe.kz/sites/default/files/2024-09/GettyImages-1466623971.jpg"),
            MenuItem("Латте", "Напитки", 190,
                     "Эспрессо, молоко, молочная пена",
                     "https://www.torrefacto.ru/upload/uf/d00/mdoibknztzibkoforsrbpa93ijzbhw9f.jpg"),
            MenuItem("Морс", "Напитки", 150,
                     "Клюква, сахар, вода",
                     "https://lifehacker.ru/wp-content/uploads/2019/09/8C304672-1662-4C9C-8073-685B93CC2B4B_1569436750.jpeg"),
            MenuItem("Свежевыжатый сок", "Напитки", 200,
                     "Апельсин или грейпфрут",
                     "https://static.zdravcity.ru/upload/main/41e/1024_768_blog-banner%20(28)-min.png"),
            MenuItem("Глинтвейн", "Напитки", 250,
                     "Красное вино, апельсин, корица",
                     "https://s3.coolclever.tech/upload/cool_admin/recipe/retsept-glintvein-anons-6571679a78caf276174832-65b36afc9153c193168962.jpg"),
            MenuItem("Смузи клубничный", "Напитки", 220,
                     "Клубника, йогурт, банан",
                     "https://www.russianfood.com/dycontent/images_upl/430/big_429410.jpg"),
            MenuItem("Чай зеленый", "Напитки", 120,
                     "Зеленый чай с жасмином",
                     "https://dachatea.ru/system/uploads/blog/file/81/1.jpg"),
            MenuItem("Лимонад", "Напитки", 170,
                     "Лимон, мята, сахар, газировка",
                     "https://images.gastronom.ru/upEEviik6nPDEiGvJSmv630HGMHLqA0yNiUNZVfZVjc/pr:recipe-step-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzLzcwNGQyMzNmLWFhMjYtNDY2NS1hYmYzLWUxODdhZGQ2ODcwZi5qcGVn.webp"),
            MenuItem("Мохито", "Напитки", 250,
                     "Ром, мята, лайм, сахарный сироп, содовая",
                     "https://static.1000.menu/img/content-v2/90/82/27700/moxito-bezalkogolnyi_1683013724_0_max.jpg"),
            MenuItem("Горячий шоколад", "Напитки", 190,
                     "Молоко, шоколад, взбитые сливки",
                     "https://images.gastronom.ru/VB9jhvCbXKzqxhvu4rdXwQrw3pTlgYCqGUHL30oAtlM/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzLzEwMTFkNjk5LTVkYzAtNDA3NS1hYTg1LWE1NmEwMzQ2MmQ1MC5qcGc.webp"),
            MenuItem("Раф кофе", "Напитки", 210,
                     "Эспрессо, сливки, ванильный сахар",
                     "https://images.gastronom.ru/R2tO6aTuXyg6Hsqx6rwSMushYvJIv2VvDEzWfxibgI4/pr:recipe-cover-image/g:ce/rs:auto:0:0:0/L2Ntcy9hbGwtaW1hZ2VzL2JkYjE0OWFlLTIzNzMtNDk5Mi05NTY1LWYwNmJlOTExMjI1OC5qcGc.webp"),
            MenuItem("Матча латте", "Напитки", 230,
                     "Японский зеленый чай матча, молоко",
                     "https://artoftea.ru/image/catalog/dariaaprst/assets_task_01jv2cn3h1ehfrb2x07h98w6gh_1747058402_img_1.webp"),
        ]

    def load_images(self):
        """Загрузка изображений"""
        for item in self.menu_items:
            if item.image_url:
                loader = ImageLoader(item.image_url, item.name)
                loader.image_loaded.connect(self.on_image_loaded)
                loader.start()
                self.image_loaders.append(loader)

    def on_image_loaded(self, dish_name, pixmap):
        """Обработка загруженного изображения"""
        for item in self.menu_items:
            if item.name == dish_name:
                item.image_pixmap = pixmap
                break
        self.display_menu_grid()
        self.update_order_display()
        if hasattr(self, 'detail_layout') and self.selected_dish and self.selected_dish.name == dish_name:
            self.update_detail_tab(self.selected_dish)

    def setup_ui(self):
        """Настройка интерфейса с 4 вкладками"""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(10, 10, 10, 10)

        self.tab_widget = QTabWidget()
        self.tab_widget.setTabPosition(QTabWidget.North)
        layout.addWidget(self.tab_widget)

        self.menu_tab = self.create_menu_tab()
        self.tab_widget.addTab(self.menu_tab, "🍽️ МЕНЮ")

        self.detail_tab = self.create_detail_tab()
        self.tab_widget.addTab(self.detail_tab, "👁️ ДЕТАЛИ БЛЮДА")
        self.tab_widget.setTabEnabled(1, False)

        self.order_tab = self.create_order_tab()
        self.tab_widget.addTab(self.order_tab, "🛒 ТЕКУЩИЙ ЗАКАЗ")

        self.checkout_tab = self.create_checkout_tab()
        self.tab_widget.addTab(self.checkout_tab, "📝 ОФОРМЛЕНИЕ ЗАКАЗА")
        self.tab_widget.setTabEnabled(3, False)

    def create_menu_tab(self):
        """Создание вкладки с меню"""
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(15)

        title_widget = QWidget()
        title_widget.setStyleSheet("""
            background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                stop:0 #4CAF50, stop:1 #45a049);
            border-radius: 15px;
        """)
        title_layout = QVBoxLayout(title_widget)

        title = QLabel("🍕 Меню 🍜")
        title.setFont(QFont("Segoe UI", 24, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: white; padding: 20px;")
        title_layout.addWidget(title)

        layout.addWidget(title_widget)

        categories_widget = QWidget()
        categories_layout = QHBoxLayout(categories_widget)
        categories_layout.setSpacing(10)

        categories = ["Все"] + sorted(list(set(item.category for item in self.menu_items)))
        self.category_buttons = []

        for category in categories:
            default_color = "#4CAF50" if category == "Все" else "#2196F3"
            btn = ModernButton(category, default_color)
            btn.clicked.connect(self.filter_menu)
            categories_layout.addWidget(btn)
            self.category_buttons.append(btn)

        categories_layout.addStretch()
        layout.addWidget(categories_widget)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setStyleSheet("border: none; background-color: transparent;")

        self.menu_grid_widget = QWidget()
        self.menu_grid_widget.setStyleSheet("background-color: transparent;")
        self.menu_grid_layout = QGridLayout(self.menu_grid_widget)
        self.menu_grid_layout.setSpacing(20)
        self.menu_grid_layout.setContentsMargins(10, 10, 10, 10)

        scroll_area.setWidget(self.menu_grid_widget)
        layout.addWidget(scroll_area)

        self.current_category = "Все"
        self.display_menu_grid()

        return tab

    def display_menu_grid(self):
        """Отображение карточек блюд"""
        for i in reversed(range(self.menu_grid_layout.count())):
            widget = self.menu_grid_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        filtered_items = [item for item in self.menu_items
                          if self.current_category == "Все" or item.category == self.current_category]

        row = 0
        col = 0
        max_cols = 4

        for item in filtered_items:
            card = DishCard(item)
            card.dish_clicked.connect(self.dish_selected)
            self.menu_grid_layout.addWidget(card, row, col)

            col += 1
            if col >= max_cols:
                col = 0
                row += 1

    def filter_menu(self):
        """Фильтрация меню с обновлением цвета кнопок"""
        button = self.sender()
        selected_category = button.text()

        if self.current_category == selected_category:
            return

        self.current_category = selected_category
        self.display_menu_grid()

        for btn in self.category_buttons:
            if btn.text() == "Все":
                btn.set_active(self.current_category == "Все")
            else:
                btn.set_active(btn.text() == self.current_category)

    def dish_selected(self, menu_item):
        self.selected_dish = menu_item
        self.update_detail_tab(menu_item)
        self.tab_widget.setTabEnabled(1, True)
        self.tab_widget.setCurrentIndex(1)

    def update_detail_tab(self, menu_item):
        for i in reversed(range(self.detail_layout.count())):
            widget = self.detail_layout.itemAt(i).widget()
            if widget:
                widget.deleteLater()

        content_widget = QWidget()
        content_layout = QVBoxLayout(content_widget)
        content_layout.setAlignment(Qt.AlignTop)
        content_layout.setSpacing(20)

        image_container = QWidget()
        image_container.setStyleSheet("""
            background-color: #f8f9fa;
            border-radius: 20px;
            padding: 20px;
        """)
        image_layout = QVBoxLayout(image_container)

        image_label = QLabel()
        image_label.setAlignment(Qt.AlignCenter)
        image_label.setMinimumHeight(350)

        if menu_item.image_pixmap and not menu_item.image_pixmap.isNull():
            pixmap = menu_item.image_pixmap.scaled(500, 350, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            image_label.setPixmap(pixmap)
        else:
            image_label.setText("🍽️")
            image_label.setFont(QFont("Segoe UI Emoji", 100))

        image_layout.addWidget(image_label)
        content_layout.addWidget(image_container)

        info_container = QWidget()
        info_container.setStyleSheet("""
            background-color: white;
            border-radius: 15px;
            padding: 20px;
        """)
        info_layout = QVBoxLayout(info_container)

        name_label = QLabel(menu_item.name)
        name_label.setFont(QFont("Segoe UI", 28, QFont.Bold))
        name_label.setStyleSheet("color: #2c3e50;")
        info_layout.addWidget(name_label)

        price_label = QLabel(f"💰 {menu_item.price} ₽")
        price_label.setFont(QFont("Segoe UI", 20, QFont.Bold))
        price_label.setStyleSheet("color: #e74c3c;")
        info_layout.addWidget(price_label)

        ingredients_title = QLabel("📋 Состав блюда:")
        ingredients_title.setFont(QFont("Segoe UI", 14, QFont.Bold))
        ingredients_title.setStyleSheet("color: #34495e; margin-top: 15px;")
        info_layout.addWidget(ingredients_title)

        ingredients_text = QLabel(menu_item.ingredients)
        ingredients_text.setFont(QFont("Segoe UI", 12))
        ingredients_text.setWordWrap(True)
        ingredients_text.setStyleSheet("color: #7f8c8d; padding: 10px; background-color: #f8f9fa; border-radius: 10px;")
        info_layout.addWidget(ingredients_text)

        content_layout.addWidget(info_container)

        add_button = ModernButton("➕ Добавить в заказ", "#4CAF50")
        add_button.clicked.connect(lambda: self.add_to_order(menu_item))
        content_layout.addWidget(add_button)

        self.detail_layout.addWidget(content_widget)

    def create_detail_tab(self):
        tab = QWidget()
        self.detail_layout = QVBoxLayout(tab)
        self.detail_layout.setContentsMargins(20, 20, 20, 20)
        return tab

    def add_to_order(self, menu_item):
        for i, (item, qty) in enumerate(self.order_items):
            if item.name == menu_item.name:
                self.order_items[i] = (item, qty + 1)
                self.update_order_display()
                QMessageBox.information(self, "Добавлено",
                                        f"✓ {menu_item.name}\nДобавлен в заказ!")
                return

        self.order_items.append((menu_item, 1))
        self.update_order_display()
        QMessageBox.information(self, "Добавлено",
                                f"✓ {menu_item.name}\nДобавлен в заказ!")
        self.tab_widget.setTabEnabled(3, True)

    def create_order_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(15)

        title = QLabel("🛒 Ваш заказ")
        title.setFont(QFont("Segoe UI", 20, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #2c3e50; padding: 10px;")
        layout.addWidget(title)

        self.order_list_widget = QListWidget()
        self.order_list_widget.setStyleSheet("""
            QListWidget {
                border: none;
                background-color: transparent;
            }
            QListWidget::item {
                background-color: transparent;
                padding: 5px;
            }
        """)
        layout.addWidget(self.order_list_widget)

        total_container = QWidget()
        total_container.setStyleSheet("""
            background-color: #f8f9fa;
            border-radius: 10px;
            padding: 10px;
        """)
        total_layout = QHBoxLayout(total_container)

        total_label_text = QLabel("Итого:")
        total_label_text.setFont(QFont("Segoe UI", 16, QFont.Bold))
        total_layout.addWidget(total_label_text)

        total_layout.addStretch()

        self.total_label = QLabel("0 ₽")
        self.total_label.setFont(QFont("Segoe UI", 18, QFont.Bold))
        self.total_label.setStyleSheet("color: #e74c3c;")
        total_layout.addWidget(self.total_label)

        layout.addWidget(total_container)

        buttons_layout = QHBoxLayout()
        buttons_layout.setSpacing(15)

        self.call_waiter_btn = ModernButton("🔔 Вызов официанта", "#FF9800", False)
        self.call_waiter_btn.clicked.connect(self.call_waiter)
        buttons_layout.addWidget(self.call_waiter_btn)

        self.place_order_btn = ModernButton("📝 Сделать заказ", "#2196F3", False)
        self.place_order_btn.clicked.connect(self.go_to_checkout)
        buttons_layout.addWidget(self.place_order_btn)

        layout.addLayout(buttons_layout)
        layout.addStretch()

        return tab

    def update_order_display(self):
        self.order_list_widget.clear()

        if not self.order_items:
            empty_widget = QWidget()
            empty_layout = QVBoxLayout(empty_widget)
            empty_label = QLabel("🛒 Ваш заказ пуст\n\nДобавьте блюда из меню!")
            empty_label.setAlignment(Qt.AlignCenter)
            empty_label.setFont(QFont("Segoe UI", 14))
            empty_label.setStyleSheet("color: #999; padding: 50px;")
            empty_layout.addWidget(empty_label)

            item = QListWidgetItem(self.order_list_widget)
            item.setSizeHint(empty_widget.sizeHint())
            self.order_list_widget.setItemWidget(item, empty_widget)

            self.total_label.setText("0 ₽")

            self.call_waiter_btn.setEnabled(False)
            self.place_order_btn.setEnabled(False)
            self.tab_widget.setTabEnabled(3, False)
            return

        total = 0
        for menu_item, quantity in self.order_items:
            item_total = menu_item.price * quantity
            total += item_total

            order_widget = OrderItem(menu_item, quantity)

            list_item = QListWidgetItem(self.order_list_widget)
            list_item.setSizeHint(order_widget.sizeHint())
            self.order_list_widget.setItemWidget(list_item, order_widget)

        self.total_label.setText(f"{total} ₽")

        self.call_waiter_btn.setEnabled(True)
        self.place_order_btn.setEnabled(True)
        self.tab_widget.setTabEnabled(3, True)

    def call_waiter(self):
        msg = QMessageBox()
        msg.setIcon(QMessageBox.Information)
        msg.setWindowTitle("Вызов официанта")
        msg.setText("🔔 Вы вызвали официанта, ожидайте")
        msg.setInformativeText("Скоро к вам подойдут!")
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec_()

    def create_checkout_tab(self):
        tab = QWidget()
        layout = QVBoxLayout(tab)
        layout.setSpacing(20)

        title = QLabel("📝 Оформление заказа")
        title.setFont(QFont("Segoe UI", 20, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #2c3e50; padding: 10px;")
        layout.addWidget(title)

        order_container = QGroupBox("Состав заказа")
        order_layout = QVBoxLayout(order_container)

        self.checkout_order_info = QTextEdit()
        self.checkout_order_info.setReadOnly(True)
        self.checkout_order_info.setMaximumHeight(250)
        self.checkout_order_info.setFont(QFont("Segoe UI", 11))
        order_layout.addWidget(self.checkout_order_info)

        layout.addWidget(order_container)

        table_container = QGroupBox("Выбор столика")
        table_layout = QHBoxLayout(table_container)

        table_layout.addWidget(QLabel("Номер столика (1-10):"))
        self.table_spinbox = QSpinBox()
        self.table_spinbox.setRange(1, 10)
        self.table_spinbox.setValue(1)
        self.table_spinbox.setFont(QFont("Segoe UI", 14))
        table_layout.addWidget(self.table_spinbox)
        table_layout.addStretch()

        layout.addWidget(table_container)

        confirm_button = ModernButton("✅ Подтвердить заказ", "#4CAF50")
        confirm_button.clicked.connect(self.confirm_order)
        layout.addWidget(confirm_button)

        layout.addStretch()

        return tab

    def go_to_checkout(self):
        if not self.order_items:
            QMessageBox.warning(self, "Ошибка", "❌ Ваш заказ пуст!\nДобавьте блюда в заказ.")
            return

        order_text = "📝 Ваш заказ:\n\n"
        total = 0
        for item, qty in self.order_items:
            item_total = item.price * qty
            total += item_total
            order_text += f"• {item.name} x{qty} = {item_total} ₽\n"
        order_text += f"\n💰 Общая сумма: {total} ₽"

        self.checkout_order_info.setText(order_text)
        self.tab_widget.setCurrentIndex(3)

    def confirm_order(self):
        table_number = self.table_spinbox.value()

        order_details = f"✅ ЗАКАЗ ПОДТВЕРЖДЕН\n\n"
        order_details += f"Столик №{table_number}\n"
        order_details += f"{'=' * 40}\n\n"

        total = 0
        for item, qty in self.order_items:
            item_total = item.price * qty
            total += item_total
            order_details += f"• {item.name} x{qty} = {item_total} ₽\n"

        order_details += f"\n{'=' * 40}\n"
        order_details += f"💰 Итого: {total} ₽\n\n"
        order_details += "🙏 Спасибо за заказ!\nОжидайте официанта."

        QMessageBox.information(self, "Заказ подтвержден", order_details)

        self.order_items.clear()
        self.update_order_display()

        self.tab_widget.setTabEnabled(1, False)
        self.tab_widget.setTabEnabled(3, False)

        self.tab_widget.setCurrentIndex(0)


def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')

    window = CafeApp()
    window.showMaximized()

    sys.exit(app.exec_())


if __name__ == '__main__':
    main()